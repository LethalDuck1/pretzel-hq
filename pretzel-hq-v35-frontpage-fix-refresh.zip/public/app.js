const GAME_START_ISO="2026-03-09T15:30:00-06:00";const DEV_UNLOCK_TTL_MS=12 * 60 * 60 * 1000;const RELEASE_DATE=new Date("2026-03-09T15:30:00-06:00");const $=(id)=>document.getElementById(id);let filter="all";let lastState=null;function escapeHtml(str){return String(str ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");}function demoState(){const now=new Date().toISOString();const teams=[{id:"t1",name:"Orange Squad"},{id:"t2",name:"Blue Squad"},{id:"t3",name:"Pretzel Ops"},];const mk=(id,name,teamId,status,kills)=>({id,name,teamId,status,kills,updatedAt:now});const players=[ mk("p1","Ava","t1","alive",2),mk("p2","Ben","t1","alive",1),mk("p3","Cody","t1","pending",0),mk("p4","Dani","t1","eliminated",0),mk("p5","Eli","t1","alive",0),mk("p6","Finn","t2","alive",3),mk("p7","Gabe","t2","revived",1),mk("p8","Hana","t2","alive",0),mk("p9","Ivy","t2","eliminated",0),mk("p10","Jace","t2","alive",1),mk("p11","Kira","t3","alive",0),mk("p12","Liam","t3","pending",0),mk("p13","Maya","t3","alive",2),mk("p14","Noah","t3","alive",0),mk("p15","Owen","t3","eliminated",0),];const log=[{id:"l1",ts:now,msg:"Preview data loaded(not the real game)."},{id:"l2",ts:now,msg:"Example:Finn gained a kill."},{id:"l3",ts:now,msg:"Example:Cody marked pending for review."},];return{lastUpdated:now,teams,players,log,_demo:true};}function fmtTime(ts){try{const d=new Date(ts);return d.toLocaleString(undefined,{hour:"numeric",minute:"2-digit"});}catch{return "—";}}function countdownParts(ms){const s=Math.max(0,Math.floor(ms/1000));const days=Math.floor(s / 86400);const hours=Math.floor((s % 86400)/ 3600);const mins=Math.floor((s % 3600)/ 60);const secs=s % 60;return{days,hours,mins,secs};}function renderTimer(){const now=new Date();const delta=RELEASE_DATE-now;const p=countdownParts(delta);const timer=$("timer");timer.innerHTML="";[{num:p.days,lbl:"DAYS"},{num:p.hours,lbl:"HOURS"},{num:p.mins,lbl:"MIN"},{num:p.secs,lbl:"SEC"},].forEach(b=>{const el=document.createElement("div");el.className="timebox";el.innerHTML=`<div class="num">${String(b.num).padStart(2,"0")}</div><div class="lbl">${b.lbl}</div>`;timer.appendChild(el);});const dev=devUnlockValid()&& now<RELEASE_DATE;const unlocked=(now>=RELEASE_DATE)|| dev;$("revealTitle").textContent=unlocked ? "HQ Live":"Countdown Lock";$("revealBadge").textContent=unlocked ? "UNLOCKED":"LOCKED";$("revealFoot").textContent=unlocked ?(dev ? "Preview mode(admin unlock).":"Live board is active."):"HQ unlocks March 9 at 3:30 PM(America/Chicago)";$("lockedNotice").style.display=unlocked ? "none":"grid";$("liveBoard").style.display=unlocked ? "grid":"none";$("statsRow").style.display=unlocked ? "grid":"none";return unlocked;}async function fetchState(){const res=await fetch("/.netlify/functions/getState",{cache:"no-store"});if(!res.ok)throw new Error("Failed to load state");const data=await res.json();const dev=devUnlockValid()&&(Date.now()<RELEASE_DATE.getTime());if(dev &&(!data?.teams?.length)&&(!data?.players?.length))return demoState();return data;}function statusBadge(status){const s=(status || "alive").toLowerCase();if(s==="alive")return `<span class="badge b-alive">ALIVE</span>`;if(s==="pending")return `<span class="badge b-pending">PENDING</span>`;if(s==="eliminated")return `<span class="badge b-elim">ELIMINATED</span>`;if(s==="revived")return `<span class="badge b-rev">REVIVED</span>`;return `<span class="badge">UNKNOWN</span>`;}function teamPill(aliveCount,total){if(aliveCount<=0)return `<span class="team-pill" style="border-color:rgba(255,77,109,.35);background:rgba(255,77,109,.10)">WIPED</span>`;if(aliveCount===total && total>0)return `<span class="team-pill" style="border-color:rgba(53,208,127,.35);background:rgba(53,208,127,.10)">FULL</span>`;return `<span class="team-pill" style="border-color:rgba(255,209,102,.35);background:rgba(255,209,102,.10)">ACTIVE</span>`;}function render(state){const feed=$("feed");
    // Merge kill feed + admin log into one "Live Feed"
    const kill=(state.killFeed || []).map(e=>({ts:e.ts || e.time || e.createdAt || e.at || null, kind:"kill", text:e.text || (e.killer && e.victim ? `🔥 ${e.killer} eliminated ${e.victim}` : (e.killer?`🔥 ${e.killer}`:"🔥 Elimination"))}));
    const logs=(state.log || []).map(e=>({ts:e.ts || null, kind:"log", text:e.text || ""}));
    const merged=[...kill, ...logs].filter(x=>x.text).sort((a,b)=>new Date(b.ts||0)-new Date(a.ts||0)).slice(0,14);

    feed.innerHTML=merged.length ? "" : `<div class="feed-item"><div class="feed-text">No updates yet</div><div class="feed-time">—</div></div>`;
    merged.forEach(item=>{
      const el=document.createElement("div");
      el.className="feed-item";
      const prefix = item.kind==="kill" ? "" : "";
      el.innerHTML=`<div class="feed-top"><div class="feed-text">${escapeHtml(prefix + item.text)}</div><div class="feed-time">${fmtTime(item.ts)}</div></div>`;
      feed.appendChild(el);
    });

    // Prize pool
    try{
      const p=state.prize || {amount:0, note:"", updatedAt:null};
      const amt=Number(p.amount||0)||0;
      const amtEl=$("prizeAmount"); if(amtEl) amtEl.textContent = "$" + amt.toLocaleString(undefined,{maximumFractionDigits:2});
      const noteEl=$("prizeNote"); if(noteEl) noteEl.textContent = p.note ? p.note : "Cash on hand (entry + buybacks)";
      const updEl=$("prizeUpdated"); if(updEl) updEl.textContent = "Last updated: " + (p.updatedAt ? new Date(p.updatedAt).toLocaleString() : "—");
      const nextMilestone=Math.max(100, Math.ceil(amt/100)*100);
      const pct = nextMilestone ? Math.min(100, Math.round((amt/nextMilestone)*100)) : 0;
      const bar=$("prizeBar"); if(bar) bar.style.width = pct + "%";
    }catch(e){}
    const teams=state.teams || [];const players=state.players || [];const teamMap=new Map(teams.map(t=>[t.id,t]));const byTeam=new Map();players.forEach(p=>{const arr=byTeam.get(p.teamId)|| [];arr.push(p);byTeam.set(p.teamId,arr);});const alivePlayers=players.filter(p=>(p.status || "alive")==="alive" || p.status==="revived").length;const activeTeams=teams.filter(t=>{const ps=byTeam.get(t.id)|| [];const alive=ps.filter(p=>(p.status || "alive")==="alive" || p.status==="revived").length;return alive>0;}).length;const elims=players.filter(p=>p.status==="eliminated").length;$("statPlayers").textContent=String(alivePlayers);$("statTeams").textContent=String(activeTeams);$("statElims").textContent=String(elims);$("statUpdated").textContent=state.lastUpdated ? fmtTime(state.lastUpdated):"—";const teamsEl=$("teams");teamsEl.innerHTML="";teams .map(t=>{const ps=(byTeam.get(t.id)|| []).slice().sort((a,b)=>String(a.name||"").localeCompare(String(b.name||"")));const total=ps.length;const alive=ps.filter(p=>(p.status || "alive")==="alive" || p.status==="revived").length;const pct=total>0 ? Math.round((alive/total)*100):0;return{t,ps,total,alive,pct};}).sort((a,b)=>b.alive-a.alive || b.total-a.total || String(a.t.name||"").localeCompare(String(b.t.name||""))).forEach(tc=>{const rosterTags=tc.ps.slice(0,8).map(p=>`<span class="tag">${escapeHtml(p.name||"")}</span>`).join("");const overflow=tc.ps.length>8 ? `<span class="tag">+${tc.ps.length-8}</span>`:"";const card=document.createElement("div");card.className="team-card";card.innerHTML=`<div class="team-top"><div><div class="team-name">${escapeHtml(tc.t.name||"")}</div><div class="team-meta">Alive:<b>${tc.alive}/${tc.total}</b>• ${tc.pct}%</div></div>${teamPill(tc.alive,tc.total)}</div><div class="bar"><div style="width:${tc.pct}%"></div></div><div class="team-roster">${rosterTags}${overflow}</div>`;teamsEl.appendChild(card);});const playersEl=$("players");playersEl.innerHTML="";players .filter(p=>filter==="all" ? true:(p.status || "alive")===filter).slice().sort((a,b)=>String(a.name||"").localeCompare(String(b.name||""))).forEach(p=>{const t=teamMap.get(p.teamId);const row=document.createElement("div");row.className="player";row.innerHTML=`<div class="p-left"><div class="p-name">${escapeHtml(p.name||"")}</div><div class="p-sub">${escapeHtml(t ? t.name:"No team")}${typeof p.kills==="number" ? ` • Kills:${p.kills}`:""}</div></div>${statusBadge(p.status)}`;playersEl.appendChild(row);});}function hookFilters(){document.querySelectorAll(".fbtn").forEach(btn=>{btn.addEventListener("click",()=>{document.querySelectorAll(".fbtn").forEach(b=>b.classList.remove("active"));btn.classList.add("active");filter=btn.dataset.filter;if(lastState)render(lastState);});});}function setupInstall(){let deferredPrompt=null;const btn=document.getElementById("installBtn");window.addEventListener("beforeinstallprompt",(e)=>{e.preventDefault();deferredPrompt=e;btn.style.display="inline";});btn?.addEventListener("click",async(e)=>{e.preventDefault();if(!deferredPrompt)return;deferredPrompt.prompt();deferredPrompt=null;btn.style.display="none";});}async function tick(){try{const state=await fetchState();lastState=state;if(renderTimer())render(state);}catch(e){console.error(e);}}async function main(){if("serviceWorker" in navigator){try{await navigator.serviceWorker.register("/sw.js");}catch{}}setupInstall();hookFilters();renderTimer();setInterval(renderTimer,1000);await tick();setInterval(tick,5000);}main();let PUSH_SUB=null;async function getPublicKey(){const res=await fetch("/.netlify/functions/getVapidPublicKey",{cache:"no-store"});const data=await res.json();if(!res.ok)throw new Error(data.detail || "Push not configured");return data.publicKey;}function urlBase64ToUint8Array(base64String){const padding='='.repeat((4-base64String.length % 4)% 4);const base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/');const rawData=atob(base64);const outputArray=new Uint8Array(rawData.length);for(let i=0;i<rawData.length;++i)outputArray[i]=rawData.charCodeAt(i);return outputArray;}async function enableNotifications(){if(!("serviceWorker" in navigator))throw new Error("No service worker");if(!("PushManager" in window))throw new Error("Push not supported");const perm=await Notification.requestPermission();if(perm !=="granted")throw new Error("Permission denied");const reg=await navigator.serviceWorker.ready;const pub=await getPublicKey();const sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(pub)});PUSH_SUB=sub;await fetch("/.netlify/functions/subscribePush",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({subscription:sub,tags:["all"]})});localStorage.setItem("pretzel_push_on","1");showNotifUI();}async function disableNotifications(){try{const reg=await navigator.serviceWorker.ready;const sub=await reg.pushManager.getSubscription();if(sub){await fetch("/.netlify/functions/unsubscribePush",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({endpoint:sub.endpoint})});await sub.unsubscribe();}}catch{}localStorage.removeItem("pretzel_push_on");showNotifUI();}async function showNotifUI(){const box=document.getElementById("notifBox");if(!box)return;let supported=("serviceWorker" in navigator)&&("PushManager" in window);if(!supported){box.innerHTML=`<div class="panel"><div class="panel-head"><div class="panel-title">Notifications</div><div class="panel-note">Not supported on this browser</div></div><div style="padding:14px 16px;color:var(--muted);">Use Safari/Chrome and install to Home Screen on iPhone.</div></div>`;return;}const reg=await navigator.serviceWorker.ready;const sub=await reg.pushManager.getSubscription();const on=!!sub && localStorage.getItem("pretzel_push_on")==="1";box.innerHTML=`<div class="panel"><div class="panel-head"><div class="panel-title">Notifications</div><div class="panel-note">${on ? "Enabled":"Disabled"}</div></div><div style="padding:14px 16px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;"><button class="fbtn ${on ? "active":""}" id="notifToggle">${on ? "Disable":"Enable"}Notifications</button><div class="panel-note">iPhone:Add to Home Screen first.</div></div></div>`;document.getElementById("notifToggle")?.addEventListener("click",async()=>{try{if(on)await disableNotifications();else await enableNotifications();}catch(e){alert(e.message || "Failed");}});}async function notifLoadTeams(){try{const st=await(await fetch("/.netlify/functions/getState",{cache:"no-store"})).json();return(st.teams || []).slice().sort((a,b)=>String(a.name||"").localeCompare(String(b.name||"")));}catch{return [];}}async function notifGetPublicKey(){const res=await fetch("/.netlify/functions/getVapidPublicKey",{cache:"no-store"});const data=await res.json();if(!res.ok)throw new Error(data.detail || "Push not configured");return data.publicKey;}function b64ToUint8(base64String){const padding='='.repeat((4-base64String.length % 4)% 4);const base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/');const raw=atob(base64);const out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out;}async function notifSubscribe(tags){if(!("serviceWorker" in navigator)|| !("PushManager" in window))throw new Error("Push not supported");const perm=await Notification.requestPermission();if(perm !=="granted")throw new Error("Notifications blocked");const reg=await navigator.serviceWorker.ready;const pub=await notifGetPublicKey();const sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64ToUint8(pub)});await fetch("/.netlify/functions/subscribePush",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({subscription:sub,tags})});localStorage.setItem("pretzel_push_tags",JSON.stringify(tags));return sub;}async function notifUnsubscribe(){try{const reg=await navigator.serviceWorker.ready;const sub=await reg.pushManager.getSubscription();if(sub){await fetch("/.netlify/functions/unsubscribePush",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({endpoint:sub.endpoint})});await sub.unsubscribe();}}catch{}localStorage.removeItem("pretzel_push_tags");}async function renderNotifBox(){const box=document.getElementById("notifBox");if(!box)return;const supported=("serviceWorker" in navigator)&&("PushManager" in window);const teams=await notifLoadTeams();if(!supported){box.innerHTML=`<div class="panel"><div class="panel-head"><div class="panel-title">Notification Control Center</div><div class="panel-note">Not supported</div></div><div style="padding:14px 16px;color:var(--muted);">iPhone:Add to Home Screen first. Use Safari/Chrome.</div></div>`;return;}const reg=await navigator.serviceWorker.ready;const sub=await reg.pushManager.getSubscription();const on=!!sub;const saved=(()=>{try{return JSON.parse(localStorage.getItem("pretzel_push_tags")||"[]");}catch{return [];}})();const savedTeam=saved.find(t=>String(t).startsWith("team:"))|| "";const savedMode=saved.includes("big")? "big":"all";const teamOptions=[`<option value="">Everyone</option>`].concat(teams.map(t=>`<option value="team:${t.id}" ${savedTeam===`team:${t.id}`?"selected":""}>Team ${t.name}</option>`)).join("");box.innerHTML=`<div class="panel"><div class="panel-head"><div class="panel-title">Notification Control Center</div><div class="panel-note">${on ? "Armed":"Offline"}</div></div><div style="padding:14px 16px;display:grid;gap:10px;"><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;"><div><div class="panel-note" style="margin-bottom:6px;">Follow</div><select id="notifTeam" style="width:100%;padding:12px;border-radius:14px;border:1px solid rgba(255,255,255,.10);background:rgba(0,0,0,.22);color:var(--text);outline:none;">${teamOptions}</select></div><div><div class="panel-note" style="margin-bottom:6px;">Mode</div><select id="notifMode" style="width:100%;padding:12px;border-radius:14px;border:1px solid rgba(255,255,255,.10);background:rgba(0,0,0,.22);color:var(--text);outline:none;"><option value="all" ${savedMode==="all"?"selected":""}>All events</option><option value="big" ${savedMode==="big"?"selected":""}>Big events only</option></select></div></div><div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;"><button class="fbtn ${on?"active":""}" id="notifToggle">${on ? "Disable":"Enable"}Notifications</button><button class="fbtn" id="notifSave" style="border-color:rgba(255,209,102,.35);background:rgba(255,209,102,.10);">Save Settings</button><div class="panel-note">iPhone:Add to Home Screen first.</div></div></div></div>`;document.getElementById("notifToggle")?.addEventListener("click",async()=>{try{if(on){await notifUnsubscribe();await renderNotifBox();}else{const team=document.getElementById("notifTeam").value;const mode=document.getElementById("notifMode").value;const tags=["all"].concat(team? [team]:[]).concat(mode==="big"?["big"]:[]);await notifSubscribe(tags);await renderNotifBox();}}catch(e){alert(e.message || "Failed");}});document.getElementById("notifSave")?.addEventListener("click",async()=>{try{if(!on){alert("Enable notifications first.");return;}await notifUnsubscribe();const team=document.getElementById("notifTeam").value;const mode=document.getElementById("notifMode").value;const tags=["all"].concat(team? [team]:[]).concat(mode==="big"?["big"]:[]);await notifSubscribe(tags);alert("Saved ✅");await renderNotifBox();}catch(e){alert(e.message || "Failed");}});}(async()=>{try{await renderNotifBox();}catch{}})();function overlayRoot(){return document.getElementById("overlayRoot")|| document.body;}function showOverlay(html){const root=overlayRoot();const wrap=document.createElement("div");wrap.className="overlay";wrap.innerHTML=html;root.appendChild(wrap);return wrap;}function closeOverlay(node){try{node?.remove();}catch{}}function isMobileDevice(){const coarse=window.matchMedia && window.matchMedia("(pointer:coarse)").matches;return coarse && Math.min(window.innerWidth,window.innerHeight)<=1024;}function isStandalone(){return(window.matchMedia && window.matchMedia("(display-mode:standalone)").matches)||(window.navigator && window.navigator.standalone);}function runOnboardingOnce(){if(!isMobileDevice())return;if(localStorage.getItem("pretzel_onboard_done")==="1")return;const picker=showOverlay(`<div class="overlay-card"><div class="overlay-head"><div><div class="overlay-title">Install+Notifications</div><div class="overlay-sub">Takes ~30 seconds. One-time setup.</div></div><button class="linklike" id="obSkip">Skip</button></div><div class="overlay-body"><div class="smallnote">Pick your device to see the right steps.</div><div class="pillrow"><button class="pillbtn" id="obIOS">iPhone</button><button class="pillbtn" id="obAndroid">Android</button></div><div class="smallnote" style="margin-top:10px;">Tip:Notifications only work after you add it to your Home Screen and open it from the icon.</div></div></div>`);const finish=()=>{localStorage.setItem("pretzel_onboard_done","1");closeOverlay(picker);};picker.querySelector("#obSkip")?.addEventListener("click",finish);const play=(platform)=>{closeOverlay(picker);playTutorial(platform);};picker.querySelector("#obIOS")?.addEventListener("click",()=>play("ios"));picker.querySelector("#obAndroid")?.addEventListener("click",()=>play("android"));}function playTutorial(platform){const steps=platform==="ios" ? [{title:"Tap Share",body:"In Safari,tap the Share icon(square with arrow).",tap:{x:165,y:452}},{title:"Add to Home Screen",body:"Scroll the list and tap Add to Home Screen.",tap:{x:160,y:362}},{title:"Tap Add",body:"Confirm by tapping Add in the top-right.",tap:{x:270,y:70}},{title:"Enable Notifications",body:"Open Pretzel HQ from your Home Screen and tap Enable Notifications.",tap:{x:165,y:316}}]:[{title:"Open in Chrome",body:"Open the game site in Chrome.",tap:{x:165,y:365}},{title:"Install the app",body:"Tap ⋮ → Install app / Add to Home screen.",tap:{x:180,y:70}},{title:"Open from the icon",body:"Open Pretzel HQ from your Home Screen.",tap:{x:110,y:240}},{title:"Enable Notifications",body:"Inside the app,tap Enable Notifications.",tap:{x:120,y:300}}];let i=0;const node=showOverlay(" ");function renderDots(){return `<div class="dots">${steps.map((_,idx)=>`<div class="dot ${idx===i?'on':''}"></div>`).join("")}</div>`;}function render(){const s=steps[i];return `<div class="overlay-card"><div class="overlay-head"><div><div class="overlay-title">${platform==="ios"?"iPhone Setup":"Android Setup"}</div><div class="overlay-sub">${s.title}</div></div><button class="linklike" id="tutClose">Close</button></div><div class="overlay-body"><div class="stepwrap"><div class="phoneframe"><div class="phonebar"></div><div class="tap" style="left:${s.tap.x}px;top:${s.tap.y}px;"></div></div>${renderDots()}<div class="smallnote" style="margin-top:10px;">${s.body}</div></div><div class="pillrow" style="margin-top:14px;"><button class="pillbtn" id="tutBack" ${i===0?'disabled style="opacity:.5;cursor:not-allowed"':''}>Back</button><button class="pillbtn" id="tutNext">${i===steps.length-1?'Finish':'Next'}</button></div><div class="smallnote" style="margin-top:10px;">If you already installed it,you can close this.</div></div></div>`;}function rerender(){node.innerHTML=render();node.querySelector("#tutClose")?.addEventListener("click",()=>{localStorage.setItem("pretzel_onboard_done","1");closeOverlay(node);});node.querySelector("#tutBack")?.addEventListener("click",()=>{if(i>0){i--;rerender();}});node.querySelector("#tutNext")?.addEventListener("click",()=>{if(i<steps.length-1){i++;rerender();}else{localStorage.setItem("pretzel_onboard_done","1");closeOverlay(node);}});}rerender();}function devUnlockValid(){const raw=localStorage.getItem("pretzel_dev_unlock")|| "";if(!raw)return false;const ts=Number(raw.split("|")[0] || 0);if(!Number.isFinite(ts)|| ts<=0)return false;return(Date.now()-ts)<DEV_UNLOCK_TTL_MS;}async function tryDevUnlock(){const node=showOverlay(`<div class="overlay-card"><div class="overlay-head"><div><div class="overlay-title">Testing Unlock</div><div class="overlay-sub">Admin key required(only unlocks on your device)</div></div><button class="linklike" id="duClose">Close</button></div><div class="overlay-body"><div class="smallnote">Enter your admin key to view the app early for testing.</div><div style="margin-top:10px;display:flex;gap:10px;"><input id="duKey" placeholder="Admin key" type="password" style="flex:1;padding:12px;border-radius:14px;border:1px solid rgba(255,255,255,.10);background:rgba(0,0,0,.22);color:var(--text);outline:none;"><button class="fbtn" id="duGo" style="padding:12px 14px;">Unlock</button></div><div class="smallnote" style="margin-top:10px;">Unlock expires in 12 hours.</div></div></div>`);node.querySelector("#duClose")?.addEventListener("click",()=>closeOverlay(node));node.querySelector("#duGo")?.addEventListener("click",async()=>{const key=node.querySelector("#duKey")?.value || "";try{const res=await fetch("/.netlify/functions/verifyAdmin",{headers:{"x-admin-key":key}});if(!res.ok)throw new Error("Invalid key");localStorage.setItem("pretzel_dev_unlock",`${Date.now()}|1`);closeOverlay(node);location.reload();}catch(e){alert("Nope — key didn’t match.");}});}window.addEventListener('load',()=>{try{runOnboardingOnce();}catch{}try{const params=new URLSearchParams(location.search);if(params.has('dev')){const a=document.getElementById('devUnlockLink');if(a){a.style.display='inline-flex';a.addEventListener('click',(e)=>{e.preventDefault();tryDevUnlock();});}}}catch{}});

/* ---- A2HS helper (mobile only, one-time) ---- */
(function(){
  try{
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent || "");
    if(!isMobile) return;

    const isStandalone = (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || (navigator.standalone === true);
    if(isStandalone) return;

    const KEY = "pretzel_a2hs_dismiss_v1";
    if(localStorage.getItem(KEY)==="1") return;

    let deferredPrompt = null;
    window.addEventListener("beforeinstallprompt", (e)=>{
      e.preventDefault();
      deferredPrompt = e;
    });

    function makeBanner(){
      const b=document.createElement("div");
      b.setAttribute("style",
        "position:fixed;left:14px;right:14px;bottom:14px;z-index:9999;"+
        "border:1px solid rgba(255,255,255,.12);border-radius:18px;"+
        "background:rgba(0,0,0,.55);backdrop-filter: blur(14px);"+
        "padding:12px 12px 10px;box-shadow:0 14px 40px rgba(0,0,0,.45);"+
        "color:var(--text);font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;"
      );
      b.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
          <div style="font-weight:800;letter-spacing:.2px;">Add Pretzel HQ to Home Screen</div>
          <button id="a2hs_x" style="all:unset;cursor:pointer;color:var(--muted);font-size:18px;padding:4px 8px;">✕</button>
        </div>
        <div style="margin-top:6px;color:var(--muted);font-size:13px;line-height:1.35;">
          Faster launch + notifications work best when it's installed like an app.
        </div>
        <div style="display:flex;gap:10px;margin-top:10px;">
          <button id="a2hs_install" style="flex:1;cursor:pointer;border-radius:14px;padding:10px 12px;border:1px solid rgba(255,209,102,.35);background:rgba(255,209,102,.12);color:var(--text);font-weight:800;">Install</button>
          <button id="a2hs_hide" style="cursor:pointer;border-radius:14px;padding:10px 12px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:var(--muted);font-weight:700;">Not now</button>
        </div>
        <div id="a2hs_steps" style="display:none;margin-top:10px;border-top:1px solid rgba(255,255,255,.08);padding-top:10px;color:var(--muted);font-size:13px;line-height:1.35;"></div>
      `;
      document.body.appendChild(b);

      const stepsEl=b.querySelector("#a2hs_steps");

      function showIOSSteps(){
        // Safari iOS: no real install prompt
        stepsEl.style.display="block";
        stepsEl.innerHTML = `
          <div style="color:var(--text);font-weight:800;margin-bottom:6px;">iPhone / iPad</div>
          <div>1) Tap the <b>Share</b> button (square with arrow)</div>
          <div>2) Scroll and tap <b>Add to Home Screen</b></div>
          <div>3) Tap <b>Add</b></div>
        `;
      }

      b.querySelector("#a2hs_x").onclick=()=>{ localStorage.setItem(KEY,"1"); b.remove(); };
      b.querySelector("#a2hs_hide").onclick=()=>{ localStorage.setItem(KEY,"1"); b.remove(); };
      b.querySelector("#a2hs_install").onclick=async()=>{
        const isiOS = /iPhone|iPad|iPod/i.test(navigator.userAgent || "");
        if(isiOS && !deferredPrompt){
          showIOSSteps();
          return;
        }
        if(!deferredPrompt){
          // Android Chrome should have it, but if not, show generic steps
          stepsEl.style.display="block";
          stepsEl.innerHTML = `
            <div style="color:var(--text);font-weight:800;margin-bottom:6px;">Android</div>
            <div>1) Tap the <b>⋮</b> menu</div>
            <div>2) Tap <b>Install app</b> or <b>Add to Home screen</b></div>
          `;
          return;
        }
        deferredPrompt.prompt();
        const choice = await deferredPrompt.userChoice.catch(()=>null);
        deferredPrompt = null;
        localStorage.setItem(KEY,"1");
        b.remove();
      };

      // auto-hide after a bit
      setTimeout(()=>{ if(document.body.contains(b)){ b.style.opacity="0"; setTimeout(()=>b.remove(),350); } }, 18000);
    }

    // show after first paint
    window.addEventListener("load", ()=> setTimeout(makeBanner, 1200), { once:true });
  }catch(_e){}
})();

/* v35 front page countdown/log fix */
(function(){
  function $(id){return document.getElementById(id)}
  function sw(which){
    var b1=$('mainTabBoard'),b2=$('mainTabFeed'),p1=$('boardPanel'),p2=$('feedPanel');
    if(!b1||!b2||!p1||!p2) return;
    var on=which==='board';
    p1.style.display=on?'':'none'; p2.style.display=on?'none':'';
    b1.classList.toggle('active',on); b2.classList.toggle('active',!on);
  }
  function renderLog(log){
    var box=$('frontLogList'); if(!box) return;
    var items=Array.isArray(log)?log.slice().reverse().slice(0,50):[];
    if(!items.length){box.innerHTML='<div class="front-log-item">No updates yet.</div>'; return;}
    box.innerHTML=items.map(function(it){
      var text=String((it&&(it.text||it.msg||it.message))||'').replace(/</g,'&lt;');
      var ts=it&&it.ts?new Date(it.ts).toLocaleString():'';
      return '<div class="front-log-item">'+text+'<span class="front-log-time">'+ts+'</span></div>';
    }).join('');
  }
  function hideCd(){
    try{
      var panels=[].slice.call(document.querySelectorAll('.panel'));
      var t=panels.find(function(x){return /Countdown Lock/i.test(x.innerText||'')});
      if(!t) return;
      var txt=(t.innerText||'').toUpperCase();
      if((txt.includes('00')&&txt.includes('DAYS')&&txt.includes('HOURS'))||txt.includes('UNLOCKED')) t.style.display='none';
    }catch(e){}
  }
  document.addEventListener('DOMContentLoaded',function(){
    var b1=$('mainTabBoard'),b2=$('mainTabFeed');
    if(b1) b1.addEventListener('click',function(){sw('board')});
    if(b2) b2.addEventListener('click',function(){sw('feed')});
    sw('board'); setTimeout(hideCd,500); setTimeout(hideCd,1500);
  });
  var oldFetch=window.fetch;
  window.fetch=async function(){
    var res=await oldFetch.apply(this,arguments);
    try{
      var url=String(arguments[0]&&arguments[0].url?arguments[0].url:arguments[0]);
      if(url.indexOf('/.netlify/functions/getState')!==-1){
        var clone=res.clone();
        clone.json().then(function(d){ var st=d.state||d||{}; renderLog(st.log||[]); setTimeout(hideCd,50); }).catch(function(){});
      }
    }catch(e){}
    return res;
  };
})();
